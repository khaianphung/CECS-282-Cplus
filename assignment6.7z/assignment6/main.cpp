#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <cstring>

#include <cstdlib>
using namespace std;

int SIZE = 10;
int elNum = 0;


int *initializeArray()
{


    int *dArray = new int[SIZE];
    for (int i = 0; i<SIZE; i++)
    {

        dArray[i] = 0;

    }
    return dArray;

}




void displayArray(int *arr,int SIZE)
{
    for (int i = 0; i<SIZE; i++)
    {

        cout<<arr[i]<<" ";

    }
}
void increaseSize(int *&dArray)
{
    SIZE *=2;
    int * tempArr = new int[SIZE];
    for (int i = 0; i < elNum; i++)
    {
        tempArr[i] = dArray[i];
    }

    delete[] dArray;
    dArray = tempArr;
    initializeArray();

}
void addValue(int num, int *&dArray)
{
    if (elNum >= SIZE)
    {
        increaseSize(dArray);
    }
    dArray[elNum] = num;
    elNum++;
}



void swapping(int a, int b)
{
    int swapi = a;
    a=b;
    b= swapi;

}

void inserting(int num, int index, int*&dArray)
{

    if (elNum >= SIZE)
    {
        increaseSize(dArray);
    }
    for(int i = 0; i<elNum; i++)
    {

        if (i == index)
        {
            for(; i<elNum; i++)
            {
                dArray[i+1] = dArray[i];
            }

        }

    }
    dArray[index] = num;
    elNum++;
}

void removing(int index, int *&dArray)
{
    for(int i = 0; i<elNum; i++)
    {
        if (i == index)
        {

            for(; i<elNum; i++)
            {
                dArray[i] = dArray[i+1];
            }

        }


    }
    elNum--;

}

void selectionSort( int *&dArray )
{
    cout<<"SIZE: "<<SIZE<<endl;
    for(int i=0; i < elNum; i++)
    {
        int lowest = i;
        for( int j= i +1; j< elNum; j++)
        {
            if( dArray[j] < dArray[lowest])
            {
                lowest = j;
            }
        }//cout<<dArray[lowest];
        int swapi = dArray[i];
        dArray[i] = dArray[lowest];
        dArray[lowest] = swapi;
    }
}


int validate(int start, int endi)
{
    int input = 0;
    bool fail= true;

    while (fail)
    {

        //cout<<"Enter a number: "<<endl;
        if (cin >> input)
        {
            if (input<= endi && input>=start )
            {
                fail = false;
            }
            else
            {
                cout<<"Invalid input: "<<endl;
            }
        }
        else
        {
            cin.clear();//clear the wrong input
            string invalid;
            cin >> invalid;
            cout << "Invalid Input" << endl;
        }
    }
    return input;
}


void reading(int *&dArray)
{
    cout<<"Enter file to read: "<<endl;
    cout<<"File 1"<<endl;
    cout<<"File 2"<<endl;
    cout<<"File 3"<<endl;
    int choice = validate(1,3);


    ifstream file;
    if (choice==1)
    {
        cout<<"File 1: "<<endl;
        file.open ("file1.txt");
    }
    if (choice==2)
    {
        cout<<"File 2: "<<endl;
        file.open ("file2.txt");
    }
    if (choice==3)
    {
        cout<<"File 3: "<<endl;
        file.open ("file3.txt");
    }


    string input ;
    string line = " ";

    if( file)
    {
        while( getline(file, input, '-') )
        {
            int a = atoi(input.c_str());
            cout<<a<< " ";
            addValue(a,dArray);

        }
        file.close();
    }
    else
    {
        cout << "Could Not Open File."<< endl;
    }
    /*
    while(file){
        getline(file, input, ',');
         cout<<input<<endl;

     cout<<input;

    }
    */




}

/*
int * getInts( int & itemsRead )
{
    int arraySize = 0;
    int inputVal;
    int *array = NULL; // Initialize to NULL pointer

    itemsRead = 0;
    cout << "Enter any number of integers: ";
    while( cin >> inputVal )
    {
        if( itemsRead == arraySize )
        {
            // Array doubling code
            int *original = array;
            array = new int[ arraySize * 2 + 1 ];
            for( int i = 0; i < arraySize; i++ )
                array[ i ] = original[ i ];
            delete [ ] original; // Safe if Original is NULL
            arraySize = arraySize * 2 + 1;
        }
        array[ itemsRead++ ] = inputVal;
    }
    return array;
}*/
int main()
{
    int *arr= initializeArray();

    bool play = true;
    while (play)
    {
        cout<<"Menu: "<<endl;
        cout<<"1.Add from file "<<endl;
        cout<<"2.Display content "<<endl;
        cout<<"3.Add new value to end "<<endl;
        cout<<"4.Insert new value"<<endl;
        cout<<"5.Sort value "<<endl;
        cout<<"6.Remove value"<<endl;
        cout<<"7.Quit"<<endl;
        int choice = validate(1,7);
        switch(choice)
        {
        case 1:
        {
            reading(arr);

            break;
        }
        case 2:
        {
            displayArray(arr, elNum);
            break;
        }
        case 3:
        {
            cout<<"Enter value to add:";
            int num = validate(-99999,99999);
            addValue(num,arr);
            break;
        }
        case 4:
        {
            cout<<"Enter value to add:";
            int num = validate(-99999,99999);
            cout<<"Enter index, must be less than "<<elNum<<":" ;
            int index = validate(0,elNum);
            inserting(num, index, arr);
            break;
        }
        case 5:
        {
            selectionSort(arr);
            displayArray(arr, elNum);
            break;
        }
        case 6:
        {
            cout<<"Enter index, must be less than "<<elNum<<":" ;
            int index = validate(-1,elNum);
            removing(index,arr);
            break;
        }
        case 7:
        {
            play= false;
            break;
        }
        default:
        {
            break;
        }

        }
    }


    delete[] arr;
     arr = NULL;


    return 0;
}
